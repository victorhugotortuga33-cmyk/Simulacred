# SimulaCred

Projeto completo de simulador de empréstimos com:
- simulador responsivo;
- cálculo de parcela pelo sistema Price;
- captura de leads;
- banco SQLite local;
- painel administrativo protegido por Basic Auth;
- estatísticas e exclusão de leads.

## Requisitos
Node.js 20+ recomendado.

## Instalação
1. Extraia o ZIP.
2. Abra o terminal na pasta.
3. Rode:
   npm install
4. Defina uma senha de administrador (recomendado):
   Linux/macOS:
   ADMIN_USER=admin ADMIN_PASS="uma-senha-forte" npm start

   Windows PowerShell:
   $env:ADMIN_USER="admin"; $env:ADMIN_PASS="uma-senha-forte"; npm start

5. Acesse:
   http://localhost:3000
   http://localhost:3000/admin

## Segurança antes de publicar
- Troque a senha padrão.
- Use HTTPS.
- Não coloque dados bancários, documentos ou senhas no formulário sem implementar proteção adequada.
- Em produção, troque/fortaleça o mecanismo de autenticação e configure controle de acesso.
- Revise LGPD, política de privacidade e base legal para tratamento dos leads.

## Observação financeira
A calculadora é uma estimativa matemática. Taxa, CET, tarifas, impostos, prazo, elegibilidade e aprovação reais variam conforme a instituição e o produto. O site não deve afirmar aprovação garantida.
