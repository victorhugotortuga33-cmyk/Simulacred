const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "troque-esta-senha";

const db = new Database(path.join(__dirname, "simulacred.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  loan_type TEXT,
  amount REAL NOT NULL,
  installments INTEGER NOT NULL,
  monthly_rate REAL NOT NULL,
  installment_value REAL NOT NULL,
  total_value REAL NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  if (!header.startsWith("Basic ")) {
    res.set("WWW-Authenticate", 'Basic realm="SimulaCred Admin"');
    return res.status(401).json({error:"Autenticação necessária"});
  }
  const decoded = Buffer.from(header.slice(6), "base64").toString();
  const idx = decoded.indexOf(":");
  const user = decoded.slice(0, idx);
  const pass = decoded.slice(idx + 1);
  if (user !== ADMIN_USER || pass !== ADMIN_PASS) {
    res.set("WWW-Authenticate", 'Basic realm="SimulaCred Admin"');
    return res.status(401).json({error:"Credenciais inválidas"});
  }
  next();
}

app.post("/api/leads", (req,res)=>{
  const {name, phone, email="", loanType="", amount, installments, monthlyRate, installmentValue, totalValue} = req.body;
  if (!name || !phone || !amount || !installments) return res.status(400).json({error:"Preencha os campos obrigatórios."});
  const stmt = db.prepare(`
    INSERT INTO leads (name, phone, email, loan_type, amount, installments, monthly_rate, installment_value, total_value)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const info = stmt.run(name.trim(), phone.trim(), email.trim(), loanType, Number(amount), Number(installments), Number(monthlyRate), Number(installmentValue), Number(totalValue));
  res.json({ok:true,id:info.lastInsertRowid});
});

app.get("/api/leads", auth, (req,res)=>{
  const rows = db.prepare("SELECT * FROM leads ORDER BY id DESC").all();
  res.json(rows);
});

app.get("/api/stats", auth, (req,res)=>{
  const total = db.prepare("SELECT COUNT(*) n FROM leads").get().n;
  const sum = db.prepare("SELECT COALESCE(SUM(amount),0) total FROM leads").get().total;
  const today = db.prepare("SELECT COUNT(*) n FROM leads WHERE date(created_at)=date('now','localtime')").get().n;
  res.json({total, sum, today});
});

app.delete("/api/leads/:id", auth, (req,res)=>{
  db.prepare("DELETE FROM leads WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.get("/admin", (req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.get("*", (req,res)=>{
  if (req.path.startsWith("/api/")) return res.status(404).json({error:"Rota não encontrada"});
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT, ()=>console.log(`SimulaCred rodando em http://localhost:${PORT}`));
