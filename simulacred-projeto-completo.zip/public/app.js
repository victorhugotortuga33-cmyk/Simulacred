let lastSimulation = null;
const brl = v => new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(v);

function simulate(){
  const amount = Number(document.querySelector("#amount").value);
  const n = Number(document.querySelector("#installments").value);
  const rate = Number(document.querySelector("#rate").value)/100;
  if(amount<=0 || n<=0 || rate<0) return alert("Confira os valores.");
  const p = rate === 0 ? amount/n : amount * (rate*Math.pow(1+rate,n))/(Math.pow(1+rate,n)-1);
  const total = p*n;
  lastSimulation={amount, installments:n, monthlyRate:rate*100, installmentValue:p,totalValue:total,loanType:document.querySelector("#loanType").value};
  document.querySelector("#resultado").hidden=false;
  document.querySelector("#installmentValue").textContent=brl(p);
  document.querySelector("#summary").textContent=`${n} parcelas • taxa estimada de ${rate*100}% ao mês • ${lastSimulation.loanType}`;
  document.querySelector("#rAmount").textContent=brl(amount);
  document.querySelector("#rTotal").textContent=brl(total);
  document.querySelector("#rInterest").textContent=brl(total-amount);
  document.querySelector("#resultado").scrollIntoView({behavior:"smooth",block:"center"});
}

async function sendLead(e){
  e.preventDefault();
  if(!lastSimulation) simulate();
  const payload={name:document.querySelector("#name").value,phone:document.querySelector("#phone").value,email:document.querySelector("#email").value,...lastSimulation};
  const msg=document.querySelector("#leadMsg");
  msg.textContent="Enviando...";
  try{
    const r=await fetch("/api/leads",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    const data=await r.json();
    if(!r.ok) throw new Error(data.error||"Erro");
    msg.textContent="Cadastro recebido! Em breve entraremos em contato.";
    e.target.reset();
  }catch(err){msg.textContent="Não foi possível enviar agora. Tente novamente."}
}
